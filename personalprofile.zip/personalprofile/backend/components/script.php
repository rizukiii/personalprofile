<!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="../../templates/assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="../../templates/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../../templates/dist/js/app-style-switcher.js"></script>
    <!--Wave Effects -->
    <script src="../../templates/dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="../../templates/dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="../../templates/dist/js/custom.js"></script>
    <!--This page JavaScript -->
    <!--chartis chart-->
    <script src="../../templates/assets/libs/chartist/dist/chartist.min.js"></script>
    <script src="../../templates/assets/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="../../templates/dist/js/pages/dashboards/dashboard1.js"></script>