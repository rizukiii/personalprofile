<?php 

$query = "SELECT * FROM `tb_carousel`";

$result = $connect->query($query);

