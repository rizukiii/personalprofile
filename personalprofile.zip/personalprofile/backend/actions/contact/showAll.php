<?php 

$query = "SELECT * FROM `tb_contact`";

$result = $connect->query($query);