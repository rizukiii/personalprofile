<?php 

$query = "SELECT * FROM `tb_about` LIMIT 1";

$result = $connect->query($query);

$about = $result->fetch_object();

if (!$about){
    die("data tidak ada !");
}