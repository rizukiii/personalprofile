<?php 

$query = "SELECT * FROM `tb_education`";

$result = $connect->query($query);