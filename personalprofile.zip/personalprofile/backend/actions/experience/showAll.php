<?php 

$query = "SELECT * FROM `tb_experience`";

$result = $connect->query($query);