<?php 

$query = "SELECT * FROM `tb_testimonial`";

$result = $connect->query($query);

