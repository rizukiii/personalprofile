<?php 

$query = "SELECT * FROM `tb_skill`";

$result = $connect->query($query);