<?php 

$query = "SELECT * FROM `tb_sosmed`";

$result = $connect->query($query);