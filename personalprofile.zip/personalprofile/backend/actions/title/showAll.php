<?php 

$query = "SELECT * FROM `tb_title`";

$result = $connect->query($query);