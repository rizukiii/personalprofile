<?php 

$query = "SELECT * FROM `tb_project`";

$result = $connect->query($query);

