<?php include "../components/head.php" ?>
   

<body data-spy="scroll" data-target=".fixed-top">
    
    <?php include "../components/navbar.php" ?>


    <?php include "../components/header.php" ?>


    <?php include "../components/about.php" ?>


    <?php include "../components/services.php" ?>


    <?php include "../components/detail.php" ?>


    <?php include "../components/project.php" ?>


    <?php include "../components/works.php" ?>


    <?php include "../components/testimonials.php" ?>


    <?php include "../components/sectiondivider.php" ?>


    <?php include "../components/question.php" ?>


    <?php include "../components/contact.php" ?>


    <?php include "../components/footer.php" ?>


    <?php include "../components/copyright.php" ?>
    
    	
    <?php include "../components/script.php" ?>
</body>
<?php include "../components/end.php" ?>